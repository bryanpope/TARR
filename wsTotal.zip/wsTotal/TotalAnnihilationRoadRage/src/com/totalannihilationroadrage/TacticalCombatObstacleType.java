package com.totalannihilationroadrage;

public enum TacticalCombatObstacleType
{
	PASSABLE,
    HAZARD,
    OBSTACLE
}
