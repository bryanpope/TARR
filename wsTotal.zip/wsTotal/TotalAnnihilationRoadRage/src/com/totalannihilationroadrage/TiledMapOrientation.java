package com.totalannihilationroadrage;

public enum TiledMapOrientation 
{
	ORTHOGONAL,
	ISOMETRIC,
	STAGGERED
}
