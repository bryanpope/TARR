package com.totalannihilationroadrage;

import com.framework.Pixmap;

public class TiledMapImage
{
	String source;
    Pixmap pmImage;
	int width;
	int height;
}
