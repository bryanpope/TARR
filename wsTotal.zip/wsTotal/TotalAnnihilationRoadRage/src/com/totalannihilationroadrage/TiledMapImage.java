package com.totalannihilationroadrage;

public class TiledMapImage 
{
	String source;
	int width;
	int height;
}
