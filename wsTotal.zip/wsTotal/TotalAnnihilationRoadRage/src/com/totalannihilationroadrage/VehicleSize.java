package com.totalannihilationroadrage;

public enum VehicleSize 
{
	SMALL,
	MEDIUM,
	LARGE
}
