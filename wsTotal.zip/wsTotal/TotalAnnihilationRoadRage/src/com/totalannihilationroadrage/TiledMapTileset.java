package com.totalannihilationroadrage;

public class TiledMapTileset 
{
	int firstGID;
	String name;
	int tileWidth;
	int tileHeight;
	int spacing;
	int margin;
}
