package com.totalannihilationroadrage;

public class Sides 
{
	int left;
	int right;
	int front;
	int back;
}
