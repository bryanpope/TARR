package com.totalannihilationroadrage;

public class TacticalCombatVehicle 
{
	VehicleStatsCurrent vehicle;
	GangMembers interior;
	GangMembers exterior;
	int xPos;
	int yPos;
	int speedCurrent;
	Direction facing;
	int maneuverability;
}
