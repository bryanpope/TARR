package com.totalannihilationroadrage;

public class GangMembers 
{
	int armsmasters;
	int bodyguards;
	int commandos;
	int dragoons;
	int escorts;
}
