package com.totalannihilationroadrage;

public enum TacticalCombatTerrainType 
{
	GRASS,
	MUD,
	SAND,
	ROAD,
	FARMLAND,
	FENCE,
	CACTUS,
	DERRICK,
	POND_LAKE,
	BUILDINGS,
	ROCKS,
	TREES,
	WRECKS
}
