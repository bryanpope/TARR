package com.totalannihilationroadrage;

public class VehicleStatsCurrent 
{
	VehicleStatsBase statsBase;
	int id;
	int structure;
	int tires;
}
